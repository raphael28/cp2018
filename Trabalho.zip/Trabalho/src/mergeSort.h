#include<stdio.h>
#include <stdlib.h>
#include <math.h>
#include <ctime>

void merge(int arr[], int l, int m, int r);
void mergeSort(int arr[], int l, int r);